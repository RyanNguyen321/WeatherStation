public class Reading {
    private Time time = new Time(0,0);
    private double temperature = 0.0;
    private double amountSinceLast = 0.0;

    public Reading(Time time, double temperature, double amountSinceLast)
    {
        this.time = time;
        this.temperature = temperature;
        this.amountSinceLast = amountSinceLast;
    }

    /**
     * Gets the temperature of reading class
     * @return double representing temperature
     */
    public double getTemp()
    {
        return this.temperature;
    }

    /**
     * Gets the rainfall amount of reading class
     * @return double representing amount of rainfall
     */
    public double getRainfall()
    {
        return this.amountSinceLast;
    }

}
