import java.util.GregorianCalendar;
import java.util.LinkedList;

public class LinkedListExtra implements ITodaysWeatherReport {

    private LinkedList<TodaysWeatherReport> reports = new LinkedList<TodaysWeatherReport>();

    /**
     * Filters out the date elements of list reports
     * @param month Month of date to be filtered out
     * @param year Year of date to be filtered out
     * @return List containing data with only certain date
     */
    public ITodaysWeatherReport findDate(int month, int year) {
        LinkedListExtra temp = new LinkedListExtra();

        for (TodaysWeatherReport element: this.reports) {
            if (element.isDate(month, year))
            {
                temp.reports.add(element);
            }
        }
        return temp;
    }

    /**
     * Gets the size of the data struct
     * @return Int representing the size
     */
    public int size()
    {
        return this.reports.size();
    }

    /**
     * Produces the average temperature of all the TodaysWeatherReport s in the LLWeatherReport
     * @return a double of all the temperatures divided by the size of the LinkedList<TodaysWeatherReport> reports,
     * computing the average temperature
     */
    public double averageTemp() {
        double temp = 0;
        int count =0;
        for (TodaysWeatherReport report: this.reports)
        {
            temp += report.averageReportTemp();
            count++;
        }
        return temp/count;
    }

    /**
     * Produces the total rainfall in the LLWeatherReport
     * @return a double of all the rainfall in the LinkedList<TodaysWeatherReport> reports added together
     */
    public double totalRainfall()  {
        double temp = 0.0;
        for (TodaysWeatherReport report: this.reports)
        {
            temp += report.sumRainfall();
        }
        return temp;
    }

    /**
     * Adds a date and data as a new TodaysWeatherReport into the current LLWeatherReport
     * @param date the date as a GregorianCalendar of the readings needed to be added
     * @param readings the LinkedList<Reading> of the TodaysWeatherReport to be created
     */
    public void add(GregorianCalendar date, LinkedList<Reading> readings) {
        LinkedList<Double> temperatureLL = new LinkedList<Double>();
        LinkedList<Double> rainfallLL = new LinkedList<Double>();

        for (Reading element : readings)
        {
            //double readingRainfall = element.getRainfall();
           // double readingTemp = element.getTemp();

            rainfallLL.add(element.getRainfall());
            temperatureLL.add(element.getTemp());
        }
        TodaysWeatherReport tempReport = new TodaysWeatherReport(date, temperatureLL, rainfallLL);
        this.reports.add(tempReport);
    }

    /**
     * Compares another object and checks if it is equal to the current one
     * @param LLExtra2 Other object to be compared(Another LinkedListExtra type)
     * @return true if they are equal
     */
    @Override
    public boolean equals(Object LLExtra2) {
        LinkedListExtra temp = (LinkedListExtra) LLExtra2;

        return this.reports.equals(temp.reports);
    }
}

