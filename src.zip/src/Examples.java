
import org.junit.Test;

import java.awt.geom.Line2D;
import java.util.GregorianCalendar;
import java.util.LinkedList;
import java.util.Random;

import static org.junit.Assert.*;

public class Examples {
GregorianCalendar today = new GregorianCalendar(2021,11,7);

@Test
public void testWeatherstation_1()
{
    ITodaysWeatherReport LLExtra = new LinkedListExtra();

    WeatherStation weatherStation = new WeatherStation(LLExtra);
    LinkedList<Reading> readings1 = new LinkedList<Reading>();
    readings1.add(new Reading(new Time(30,5), 72.0,5.0));
    readings1.add(new Reading(new Time(30,5), 80.0,0.0));
    weatherStation.addTodaysReport(today, readings1);

    assertEquals(weatherStation.averageMonthTemp(11,2021),76.0,0.0);
    assertEquals(weatherStation.totalMonthRainfall(11,2021),5.0,0.0);
}

    @Test
    public void testWeatherstation_2()
    {
        ITodaysWeatherReport LLExtra = new LinkedListExtra();

        WeatherStation weatherStation = new WeatherStation(LLExtra);
        LinkedList<Reading> readings1 = new LinkedList<Reading>();
        LinkedList<Reading> readings2 = new LinkedList<Reading>();
        readings1.add(new Reading(new Time(30,5), 72.0,5.0));
        readings1.add(new Reading(new Time(30,5), 80.0,0.0));
        weatherStation.addTodaysReport(today, readings1);

        readings2.add(new Reading(new Time(30,5), 0.0,0.0));
        readings2.add(new Reading(new Time(30,5), 5.0,0.0));
        weatherStation.addTodaysReport(new GregorianCalendar(2021,1,10), readings2);

        assertEquals(weatherStation.averageMonthTemp(11,2021),76.0,0.0);
        assertEquals(weatherStation.totalMonthRainfall(11,2021),5.0,0.0);

        assertEquals(weatherStation.averageMonthTemp(1,2021),2.5,0.0);
        assertEquals(weatherStation.totalMonthRainfall(1,2021),0.0,0.0);
    }


@Test
public void testReading_1()
{
    Reading reading = new Reading(new Time(50,13), 60.0 ,10.0);
    assertEquals(reading.getRainfall(),10.0,0);
    assertEquals(reading.getTemp(),60.0,0);
}

@Test
public void LLExtra_1()
{
    ITodaysWeatherReport LLExtra = new LinkedListExtra();
    LinkedList<Reading> readings = new LinkedList<Reading>();

    readings.add(new Reading(new Time(59,13), 72.0  ,10.0));

    LLExtra.add(today,readings);
    assertEquals(LLExtra.findDate(11,10), new LinkedListExtra());
    assertEquals(LLExtra.averageTemp(),72.0,0);
    assertEquals(LLExtra.totalRainfall(),10.0,0);
}

    @Test
    public void LLExtra_2()
    {
        ITodaysWeatherReport LLExtra = new LinkedListExtra();
        LinkedList<Reading> readings = new LinkedList<Reading>();

        readings.add(new Reading(new Time(59,13), 0.0  ,0.0));

        LLExtra.add(today,readings);
        assertEquals(LLExtra.findDate(11,2021), LLExtra);
        assertEquals(LLExtra.averageTemp(),0.0,0);
        assertEquals(LLExtra.totalRainfall(),0.0,0);
    }

    @Test
    public void LLExtra_3()
    {
        ITodaysWeatherReport LLExtra = new LinkedListExtra();
        LinkedList<Reading> readings = new LinkedList<Reading>();

        readings.add(new Reading(new Time(59,13), 72.0  ,13.0));
        readings.add(new Reading(new Time(59,13), 10.0  ,5.0));

        LLExtra.add(today,readings);
        assertEquals(LLExtra.findDate(11,2021), LLExtra);
        assertEquals(LLExtra.averageTemp(),41.0,0);
        assertEquals(LLExtra.totalRainfall(),18.0,0);
    }


@Test
    public void testReport_1()
    {
        LinkedList<Double> temperature = new LinkedList<Double>();
        LinkedList<Double> rainfall = new LinkedList<Double>();
        TodaysWeatherReport report = new TodaysWeatherReport(today,temperature,rainfall);

        temperature.add(50.0);
        temperature.add(100.0);
        rainfall.add(10.0);
        rainfall.add(3.0);

        double x = 150.0/2;
        assertEquals(report.averageReportTemp(),x, 0);
        assertEquals(report.sumRainfall(),13.0,0);
        assertEquals(report.sumTemperature(),150.0,0);
        assertTrue(report.isDate(11,2021));
    }
    @Test
    public void testReport_2()
    {
        LinkedList<Double> temperature = new LinkedList<Double>();
        LinkedList<Double> rainfall = new LinkedList<Double>();
        TodaysWeatherReport report = new TodaysWeatherReport(today);

        double x = 0.0/0;
        assertEquals(report.averageReportTemp(),x, 0);
        assertEquals(report.sumRainfall(),0.0,0);
        assertEquals(report.sumTemperature(),0.0,0);
        assertFalse(report.isDate(10,2021));
    }
    @Test
    public void testReport_3()
    {
        LinkedList<Double> temperature = new LinkedList<Double>();
        LinkedList<Double> rainfall = new LinkedList<Double>();
        TodaysWeatherReport report = new TodaysWeatherReport(today,temperature,rainfall);

        temperature.add(0.0);
        rainfall.add(0.0);
        double x = 0.0/1;

        assertEquals(report.averageReportTemp(),x, 0);
        assertEquals(report.sumRainfall(),0.0,0);
        assertEquals(report.sumTemperature(),0.0,0);
        assertFalse(report.isDate(11,2020));

    }
    @Test
    public void testReport_4()
    {
        LinkedList<Double> temperature = new LinkedList<Double>();
        LinkedList<Double> rainfall = new LinkedList<Double>();
        TodaysWeatherReport report1 = new TodaysWeatherReport(today,temperature,rainfall);
        TodaysWeatherReport report2 = new TodaysWeatherReport(today,temperature,rainfall);

        assertEquals(report1,report2);

    }
    @Test
    public void testReport_5()
    {
        LinkedList<Double> temperature1 = new LinkedList<Double>();
        LinkedList<Double> rainfall1 = new LinkedList<Double>();
        LinkedList<Double> temperature2 = new LinkedList<Double>();
        LinkedList<Double> rainfall2 = new LinkedList<Double>();
        TodaysWeatherReport report1 = new TodaysWeatherReport(today,temperature1,rainfall1);
        TodaysWeatherReport report2 = new TodaysWeatherReport(today,temperature2,rainfall2);

        temperature1.add(1.0);
        rainfall2.add(1.0);
        assertFalse(report1.equals(report2));

    }
    @Test
    public void testReport_6()
    {
        LinkedList<Double> temperature1 = new LinkedList<Double>();
        LinkedList<Double> rainfall1 = new LinkedList<Double>();
        LinkedList<Double> temperature2 = new LinkedList<Double>();
        LinkedList<Double> rainfall2 = new LinkedList<Double>();
        TodaysWeatherReport report1 = new TodaysWeatherReport(today,temperature1,rainfall1);
        TodaysWeatherReport report2 = new TodaysWeatherReport(today,temperature2,rainfall2);

        temperature1.add(0.0);
        rainfall2.add(0.0);
        assertFalse(report1.equals(report2));

    }
    @Test
    public void testReport_7()
    {
        LinkedList<Double> temperature1 = new LinkedList<Double>();
        LinkedList<Double> rainfall1 = new LinkedList<Double>();
        LinkedList<Double> temperature2 = new LinkedList<Double>();
        LinkedList<Double> rainfall2 = new LinkedList<Double>();
        TodaysWeatherReport report1 = new TodaysWeatherReport(today,temperature1,rainfall1);
        TodaysWeatherReport report2 = new TodaysWeatherReport(new GregorianCalendar(2020,9,13),temperature2,rainfall2);


        assertFalse(report1.equals(report2));

    }


}
