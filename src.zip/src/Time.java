public class Time {
    private int hour =0;
    private int min = 0;

    public Time (int min, int hour)
    {
        this.min = min;
        this.hour = hour;
    }
}
