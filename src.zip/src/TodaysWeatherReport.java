import java.util.GregorianCalendar;
import java.util.LinkedList;

public class TodaysWeatherReport {
    private GregorianCalendar date = new GregorianCalendar();
    private LinkedList<Double> temperatureLL = new LinkedList<Double>();
    private LinkedList<Double> rainfallLL = new LinkedList<Double>();

    public TodaysWeatherReport(GregorianCalendar date)
    {
        this.date = date;
    }
    public TodaysWeatherReport(GregorianCalendar date, LinkedList<Double> temperatureLL, LinkedList<Double> rainfallLL)
    {
        this.date = date;
        this.temperatureLL = temperatureLL;
        this.rainfallLL = rainfallLL;
    }


    /**
     * Produces the sum of the temperatures of the report
     * @return double representing sum of temperature in the report
     */
    public double sumTemperature()
    {
        double temp = 0.0;
        for (Double entry: this.temperatureLL)
        {
            temp +=entry;
        }
        return temp;
    }

    /**
     * Produces sum of rainfall of the report
     * @return double representing sum of rainfall in report
     */
    public double sumRainfall()
    {
        double temp = 0.0;
        for (Double entry: this.rainfallLL)
        {
            temp +=entry;
        }
        return temp;
    }

    /**
     * Produces the average temp of the report
     * @return Double representing avg temp
     */
    public double averageReportTemp()
    {
        double temp = 0.0;
        int count = 0;
        for (Double entry: this.temperatureLL)
        {
            System.out.println(temp +"temp");
            System.out.println(count+ "count");
            temp += entry;
            count++;
        }
        return (temp/count);
    }

    /**
     * Checks if the given piece of date matches a date
     * @param month Month that wants to be found
     * @param year Year that wants to be found
     * @return True if report contains given date
     */
    public boolean isDate(int month, int year)
    {
        int month1 = this.date.get(GregorianCalendar.MONTH);
        int year1 = this.date.get(GregorianCalendar.YEAR);

        if (month == month1 && year == year1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    @Override
    public boolean equals(Object o)
    {
        TodaysWeatherReport temp = (TodaysWeatherReport) o;
        int day1 = this.date.get(GregorianCalendar.DAY_OF_MONTH);
        int month1 = this.date.get(GregorianCalendar.MONTH);
        int year1 = this.date.get(GregorianCalendar.YEAR);
        LinkedList temp1 = this.temperatureLL;
        LinkedList rain1 = this.rainfallLL;


        int day2 = temp.date.get(GregorianCalendar.DAY_OF_MONTH);
        int month2 = temp.date.get(GregorianCalendar.MONTH);
        int year2 = temp.date.get(GregorianCalendar.YEAR);
        LinkedList temp2 = temp.temperatureLL;
        LinkedList rain2 = temp.rainfallLL;

        if (day1 == day2 && month1 == month2 && year1 == year2 && temp1.equals(temp2) && rain1.equals(rain2))
        {
            return true;
        }
        return false;
    }
}
