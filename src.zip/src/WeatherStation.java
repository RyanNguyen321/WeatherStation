import java.util.GregorianCalendar;
import java.util.LinkedList;

public class WeatherStation {

    private ITodaysWeatherReport reports;

    public WeatherStation(ITodaysWeatherReport reports)
    {
        this.reports = reports;
    }


    /**
     * Calcultes the average temperature over a certain month in a year
     * @param month The month that wants to be analyze
     * @param year The year the month comes from
     * @return Double representing avg temp over a month
     */
    public double averageMonthTemp(int month, int year)
    {
        ITodaysWeatherReport temp = reports.findDate(month,year);

        double averageTemp = temp.averageTemp();
        if (reports.size() > 0)
        {
            return averageTemp;
        }
        else
            return (0.0);

    }

    /**
     * Calculates the total amount of rainfall in a certain month in a year
     * @param month The month that wants to be analyzed
     * @param year The year the month comes from
     * @return Double representing the total amount of rainfall over a month
     */
    public double totalMonthRainfall(int month, int year)
    {
        ITodaysWeatherReport temp = reports.findDate(month,year);

        double totalRain = temp.totalRainfall();

        if (reports.size() > 0)
        {
            return totalRain;
        }
        else
            return 0.0;
    }

    /**
     * Adds the current report to a list of reprots
     * @param date Date of report to be added
     * @param readings List of readings of report to be added
     */
    public void addTodaysReport(GregorianCalendar date, LinkedList<Reading> readings)
    {
        reports.add(date,readings);
    }


}
