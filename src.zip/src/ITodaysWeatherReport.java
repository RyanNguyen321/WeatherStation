import java.util.LinkedList;
import java.util.GregorianCalendar;

public interface ITodaysWeatherReport {

    public double averageTemp();
    public double totalRainfall();
    public ITodaysWeatherReport findDate(int month, int year) ;
    public void add(GregorianCalendar date, LinkedList<Reading> readings);
    public int size();


}
